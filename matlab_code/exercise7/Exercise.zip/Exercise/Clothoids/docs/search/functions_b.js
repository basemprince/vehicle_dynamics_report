var searchData=
[
  ['maxdistance',['maxDistance',['../de/d56/class_g2lib_1_1_b_box.html#a9e35474d66ca0ff168dff368476066d5',1,'G2lib::BBox']]],
  ['minmax3',['minmax3',['../d4/d9f/namespace_g2lib.html#adcb636fc9381075c0ce6750a07f15a41',1,'G2lib']]]
];
