function veh_params = get_vehicle_data

    % -------------------------------------
    %% Define the vehicle parameters
    % -------------------------------------
    
    % Vehicle
    c0          = 0.1;                  % [N*s^2/m^2] aerodynamic drag coefficient
    tau_fx      = 0.1;                  % [s] time constant for the longitudinal control force
    m           = 1200;                 % [kg] vehicle mass
    Lf          = 1.3;                  % [m] distance from the vehicle CoM to the front axle
    Lr          = 1.5;                  % [m] distance from the vehicle CoM to the rear axle
    Izz         = m*(Lf + Lr)^2;        % [kg*m^2] moment of inertia around the vertical z axis (yaw inertia)
    g           = 9.81;                 % [m/s^2] acceleration due to gravity
    % Pacejka tyre data
    mu_y        = 1; 
    B           = 25;
    C           = 1.4;
    
    % Store the parameters in a struct
    veh_params.c0     = c0;
    veh_params.tau_fx = tau_fx;
    veh_params.m      = m;
    veh_params.Lf     = Lf;
    veh_params.Lr     = Lr;
    veh_params.Izz    = Izz;
    veh_params.g      = g;
    veh_params.mu_y   = mu_y;
    veh_params.B      = B;
    veh_params.C      = C;

end