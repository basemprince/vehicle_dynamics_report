function Fy = Pacejka_MF(alpha,Fz,B,C,mu_y)

    % -------------------------------------
    %% Lateral tire force
    % -------------------------------------
    
    Fy = Fz*mu_y*sin(C*atan(B*alpha));

end