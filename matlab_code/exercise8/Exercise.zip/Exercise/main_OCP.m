% ---------------------------------------------------------------------------------
%% Solve an optimal control problem using the direct collocation method in CasADi
%  authors: Mattia Piccinini & Edoardo Pagot
%  date:    11/11/2021
% ---------------------------------------------------------------------------------

clc;
clearvars;
%close all;

% --------------------------
% REPLACE IT WITH YOUR PATH TO THE CASADI FOLDER
addpath(genpath('/Users/mattiapiccinini/Documents/Google_Drive/PhD/Varie/CasADi/casadi-osx-matlabR2015a-v3.5.1'))
% --------------------------

addpath(genpath('./utilities'));

set(0,'DefaultFigureWindowStyle','docked')
set(0,'defaultAxesFontSize',20)
set(0,'DefaultLegendFontSize',20)

% Set LaTeX as default interpreter for axis labels, ticks and legends
set(0,'defaulttextinterpreter','latex')
set(groot,'defaultAxesTickLabelInterpreter','latex')
set(groot,'defaultLegendInterpreter','latex')

import casadi.*

% --------------------------
%% Define the Optimal Control Problem (OCP)
% --------------------------
% Create an instance of the class for optimal control in CasADi
ocp = Dimei();

% Degree of interpolating polynomial (direct collocation method)
d = 3;

% Set the collocation method (either 'radau' or 'legendre') 
ocp.setCollocationProperties(d,'legendre');

% Declare the state and control names
states   = {'vx','vy','Omega','Fx'};
controls = {'Fx_u','delta_u'};
ocp.setVariables(states, controls);

veh_data = get_vehicle_data;

% Define the ODE system for the OCP (IMPORTANT: it must be set AFTER defining the OCP variables)
% Continuous time dynamics
ocp.setODESystem(@VehicleDynamics);

% Define the objective function (Lagrange term of the OCP) 
ocp.setObjFun(@CostFunction);

% Initial time
t0 = 0;  % [s] 

% Time horizon [s]
T = 30;

% Control discretization 
N = 600;   % number of mesh points for the controls

% Initial conditions for the model states
X0 = load_initial_condits;
ocp.setInitConditions(X0);

% Define the bounds on the model states 
% Lower bounds
Xlb.vx      = 0;     % [m/s]
ocp.setStatesLb(Xlb);
%ocp.setStatesUb(Xub);

% Define the bounds on the model controls 
ControlBounds.lb.Fx_u = -5000;   % [N]
ControlBounds.ub.Fx_u = 5000;    % [N]
ControlBounds.lb.delta_u = -deg2rad(50);  % [rad]
ControlBounds.ub.delta_u = deg2rad(50);   % [rad]
ocp.setControlsBounds(ControlBounds);

% Define the initial guess for the states and controls (the default guess is zero for all states and controls)
Xguess.vx = X0.vx;
ocp.setStatesGuess(Xguess);

% --------------------------
%% Solve the Optimal Control Problem
% --------------------------
ocp.setup(T,N,t0);

tic;
[time_grid, sol_struct] = ocp.solve();
tot_cpu_time = toc;
fprintf('\nThe overall cpu time was %.5f s\n',tot_cpu_time)

% --------------------------
%% Post-processing
% --------------------------
post_proc_OCP;

