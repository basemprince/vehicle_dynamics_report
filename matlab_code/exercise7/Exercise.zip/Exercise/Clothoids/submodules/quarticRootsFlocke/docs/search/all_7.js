var searchData=
[
  ['quadratic',['Quadratic',['../d5/ded/class_polynomial_roots_1_1_quadratic.html',1,'PolynomialRoots']]],
  ['quartic',['Quartic',['../d8/dec/class_polynomial_roots_1_1_quartic.html',1,'PolynomialRoots']]]
];
