function Xdot = VehicleDynamics(X,U,t)

    % ------------------------------------------
    %% Dynamical system (ODE)
    % ------------------------------------------

    % ----------------- 
    % Parameters
    % -----------------
    veh_params = get_vehicle_data;
    c0     = veh_params.c0;
    tau_fx = veh_params.tau_fx;
    m      = veh_params.m;
    Lf     = veh_params.Lf;
    Lr     = veh_params.Lr;
    Izz    = veh_params.Izz;
    g      = veh_params.g;
    mu_y   = veh_params.mu_y;
    B      = veh_params.B;
    C      = veh_params.C;
    
    % ----------------- 
    % States
    % -----------------
    vx          = X(1);                 % [m/s] forward speed
    vy          = X(2);                 % [m/s] lateral speed
    Omega       = X(3);                 % [rad/s] yaw rate
    Fx          = X(4);                 % [N] sum of the longitudinal tire forces ("real" value)

    % -----------------
    % Controls
    % -----------------
    Fx_u        = U(1);                 % [N] sum of the longitudinal tire forces ("target" value)
    delta_u     = U(2);                 % [rad] steering angle 

    % -----------------
    % Side slip angles
    % -----------------
    alpha_f     = -(Omega*Lf + vy)/vx + delta_u;
    alpha_r     = -(-Omega*Lr + vy)/vx;
    
    % -----------------
    % Vertical static loads
    % -----------------
    Fz_f        = m*g*Lr/(Lf + Lr);     % [N] sum of the static vertical tire forces at the front axle
    Fz_r        = m*g*Lf/(Lf + Lr);     % [N] sum of the static vertical tire forces at the rear axle
    
    % -----------------
    % Lateral tire forces
    % -----------------
    Fy_f        = Pacejka_MF(alpha_f,Fz_f,B,C,mu_y);
    Fy_r        = Pacejka_MF(alpha_r,Fz_r,B,C,mu_y);
    
    % -----------------
    % Vehicle dynamics
    % -----------------
    Xdot = [(1/m) * (Fx - c0 * vx^2); ...           % longitudinal dynamics
            (1/m) * (Fy_f + Fy_r - Omega*vx); ...   % lateral dynamics
            (1/Izz) * (Fy_f*Lf - Fy_r*Lr); ...      % yaw rate dynamics
            (1/tau_fx) * (Fx_u - Fx)];              % longitudinal control force dynamics

end

