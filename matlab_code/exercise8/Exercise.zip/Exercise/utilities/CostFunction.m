function J = CostFunction(X,U,t)

    % -------------------------------------------------------
    %% Cost function for the optimal control problem
    %  The function inputs are:
    %       --> the model states X, at the current time t
    %       --> the model controls U, at the current time t
    %       --> the current time t
    % -------------------------------------------------------

    % -----------
    % States
    % -----------
    vx          = X(1);
    vy          = X(2);
    Omega       = X(3);
    Fx          = X(4);

    % -----------
    % Controls
    % -----------
    Fx_u        = U(1);
    delta_u     = U(2);

    % -----------
    % Target 
    % -----------
    vx_target    = min(t,15);
    Omega_target = 0;
    
    % -----------
    % Cost function weights
    % -----------
    w_vx    = 1;
    w_Omega = 1;
    w_Fx    = 1e-6;
    w_delta = 1e-4;
    
    J = w_vx*(vx - vx_target)^2 + w_Omega*(Omega - Omega_target)^2 + w_Fx*Fx_u^2 + w_delta*delta_u^2;
    
    % Uncomment these lines if a custom spline is needed to define e.g. the target speed profile
    %import casadi.*
    %xgrid = 0:0.1:100;        % time grid
    %V_pt = min(1*xgrid,15);   % spline points
    %vx_target = casadi.interpolant('vx_target','bspline',{xgrid},V_pt);
    %J = (vx - vx_target(t))^2 + (Omega - Omega_target)^2 + 1e-6*Fx_u^2 + 1e-4*delta_u^2;

end

