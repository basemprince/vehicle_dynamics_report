function X0 = load_initial_condits

    % -------------------------------------
    %% Define the initial conditions
    % -------------------------------------
    
    X0.vx       = 3;     % [m/s] initial forward speed
    X0.vy       = 0;     % [m/s] initial lateral speed
    X0.Omega    = 0;     % [rad/s] initial yaw rate
    X0.Fx       = 0;     % [N] initial longitudinal force

end