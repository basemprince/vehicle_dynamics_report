function LLC = load_LowLevelControlData()
 
    LLC.sample_time = 0.001; % [s] -> time after which the low-level controller updates its output   
                                                        
end