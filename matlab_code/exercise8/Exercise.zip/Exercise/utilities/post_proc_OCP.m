% -------------------------------------
%% Post-processing
% -------------------------------------

% ------------------
% Extract the solution
% ------------------
% Parameters
c0     = veh_data.c0;
tau_fx = veh_data.tau_fx;
m      = veh_data.m;
Lf     = veh_data.Lf;
Lr     = veh_data.Lr;
Izz    = veh_data.Izz;
g      = veh_data.g;
mu_y   = veh_data.mu_y;
B      = veh_data.B;
C      = veh_data.C;
Fz_f   = m*g*Lr/(Lf + Lr);     
Fz_r   = m*g*Lf/(Lf + Lr);
    
% States
vx_sol    = sol_struct.vx;
vy_sol    = sol_struct.vy;
Omega_sol = sol_struct.Omega;
Fx_sol    = sol_struct.Fx;

% Controls
delta_u_sol = sol_struct.delta_u;
Fx_u_sol    = sol_struct.Fx_u;

% ------------------
% Plot the states
% ------------------
figure('Name','States','NumberTitle','off'); clf
% --- vx --- %
ax(1) = subplot(221);
hold on
plot(time_grid,sol_struct.vx,'LineWidth',2)
xlabel('time [s]')
ylabel('$v_x$ [m/s]')
grid on
% --- vy --- %
ax(2) = subplot(222);
hold on
plot(time_grid,sol_struct.vy,'LineWidth',2)
xlabel('time [s]')
ylabel('$v_y$ [m/s]')
grid on
% --- Omega --- %
ax(3) = subplot(223);
hold on
plot(time_grid,sol_struct.Omega,'LineWidth',2)
xlabel('time [s]')
ylabel('$\Omega$ [rad/s]')
grid on
% --- Fx --- %
ax(4) = subplot(224);
hold on
plot(time_grid,sol_struct.Fx,'LineWidth',2)
xlabel('time [s]')
ylabel('$F_x$ [N]')
grid on

% ------------------
% Plot the controls
% ------------------
figure('Name','Controls','NumberTitle','off'); clf
% --- delta_u --- %
ax(1) = subplot(211);
hold on
plot(time_grid(1:end-1),rad2deg(sol_struct.delta_u),'LineWidth',2)
xlabel('time [s]')
ylabel('$\delta_u$ [deg]')
grid on
% --- Fx_u --- %
ax(2) = subplot(212);
hold on
plot(time_grid(1:end-1),sol_struct.Fx_u,'LineWidth',2)
xlabel('time [s]')
ylabel('$F_{x_u}$ [N]')
grid on
