var searchData=
[
  ['tripleroot',['tripleRoot',['../d9/df7/class_polynomial_roots_1_1_cubic.html#acdfaafb3b8cf6ecd43790bfa43a5a6ac',1,'PolynomialRoots::Cubic']]]
];
